import tkinter as tk
from tkinter import colorchooser, filedialog, simpledialog, messagebox
from PIL import Image, ImageDraw, ImageTk
import math

class PaintApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Pyint")

        self.width = 800
        self.height = 600
        self.color = "black"
        self.brush_size = 5
        self.mode = "brush"
        self.layers = []
        self.current_layer_index = 0
        self.sides = 5  # Количество сторон для многоугольника

        # Создаем основной холст
        self.canvas = tk.Canvas(root, width=self.width, height=self.height, bg='white')
        self.canvas.pack()

        # Создаем первый слой
        self.add_layer()

        self.last_x = None
        self.last_y = None
        self.start_x = None
        self.start_y = None
        self.temp_shape = None

        self.init_ui()

        self.canvas.bind("<Button-1>", self.on_click)
        self.canvas.bind("<B1-Motion>", self.on_drag)
        self.canvas.bind("<ButtonRelease-1>", self.on_release)
        self.canvas.bind("<MouseWheel>", self.on_mousewheel)  # Для изменения размера кисти колесиком

    def add_layer(self):
        """Добавляет новый слой"""
        layer_image = Image.new("RGBA", (self.width, self.height), (0, 0, 0, 0))
        layer_draw = ImageDraw.Draw(layer_image)
        
        self.layers.append({
            'image': layer_image,
            'draw': layer_draw,
            'visible': True
        })
        self.current_layer_index = len(self.layers) - 1
        self.update_canvas()

    def get_current_layer(self):
        """Возвращает текущий активный слой"""
        if self.layers:
            return self.layers[self.current_layer_index]
        return None

    def merge_layers(self):
        """Объединяет все видимые слои в один"""
        if not self.layers:
            return

        merged = Image.new("RGBA", (self.width, self.height), (255, 255, 255, 255))
        for layer in self.layers:
            if layer['visible']:
                merged = Image.alpha_composite(merged, layer['image'])
        
        # Оставляем только объединенный слой
        self.layers = [{
            'image': merged,
            'draw': ImageDraw.Draw(merged),
            'visible': True
        }]
        self.current_layer_index = 0
        self.update_canvas()

    def init_ui(self):
        # Основное
        frame_main = tk.Frame(self.root)
        frame_main.pack()
        tk.Button(frame_main, text="Цвет", command=self.choose_color).pack(side=tk.LEFT)
        tk.Button(frame_main, text="Кисть", command=lambda: self.set_mode("brush")).pack(side=tk.LEFT)
        tk.Button(frame_main, text="Ластик", command=lambda: self.set_mode("eraser")).pack(side=tk.LEFT)
        tk.Button(frame_main, text="Заливка", command=lambda: self.set_mode("fill")).pack(side=tk.LEFT)
        tk.Button(frame_main, text="Пипетка", command=lambda: self.set_mode("pipette")).pack(side=tk.LEFT)
        tk.Button(frame_main, text="Очистить", command=self.clear_canvas).pack(side=tk.LEFT)
        tk.Button(frame_main, text="Сохранить", command=self.save_image).pack(side=tk.LEFT)

        # Формы
        frame_shapes = tk.Frame(self.root)
        frame_shapes.pack()
        tk.Button(frame_shapes, text="Линия", command=lambda: self.set_mode("line")).pack(side=tk.LEFT)
        tk.Button(frame_shapes, text="Прямоугольник", command=lambda: self.set_mode("rect")).pack(side=tk.LEFT)
        tk.Button(frame_shapes, text="Овал", command=lambda: self.set_mode("oval")).pack(side=tk.LEFT)
        tk.Button(frame_shapes, text="Треугольник", command=lambda: self.set_mode("triangle")).pack(side=tk.LEFT)
        tk.Button(frame_shapes, text="Звезда", command=lambda: self.set_mode("star")).pack(side=tk.LEFT)
        tk.Button(frame_shapes, text="Многоугольник", command=lambda: self.set_mode("polygon")).pack(side=tk.LEFT)

        # Текст
        frame_text = tk.Frame(self.root)
        frame_text.pack()
        tk.Button(frame_text, text="Текст", command=lambda: self.set_mode("text")).pack(side=tk.LEFT)
        tk.Button(frame_text, text="Стороны", command=self.set_sides).pack(side=tk.LEFT)

        # Размер
        frame_size = tk.Frame(self.root)
        frame_size.pack()
        tk.Button(frame_size, text="Толще", command=self.increase_size).pack(side=tk.LEFT)
        tk.Button(frame_size, text="Тоньше", command=self.decrease_size).pack(side=tk.LEFT)
        self.size_label = tk.Label(frame_size, text=f"Размер: {self.brush_size}")
        self.size_label.pack(side=tk.LEFT)

        # Слои
        frame_layers = tk.Frame(self.root)
        frame_layers.pack()
        tk.Button(frame_layers, text="Добавить слой", command=self.add_layer).pack(side=tk.LEFT)
        tk.Button(frame_layers, text="Объединить слои", command=self.merge_layers).pack(side=tk.LEFT)
        tk.Button(frame_layers, text="След. слой", command=self.next_layer).pack(side=tk.LEFT)
        tk.Button(frame_layers, text="Пред. слой", command=self.prev_layer).pack(side=tk.LEFT)
        self.layer_label = tk.Label(frame_layers, text=f"Слой: {self.current_layer_index + 1}/{len(self.layers)}")
        self.layer_label.pack(side=tk.LEFT)

    def set_sides(self):
        """Устанавливает количество сторон для многоугольника"""
        sides = simpledialog.askinteger("Стороны", "Введите количество сторон:", initialvalue=self.sides, minvalue=3, maxvalue=20)
        if sides:
            self.sides = sides

    def next_layer(self):
        """Переключает на следующий слой"""
        if self.layers:
            self.current_layer_index = (self.current_layer_index + 1) % len(self.layers)
            self.layer_label.config(text=f"Слой: {self.current_layer_index + 1}/{len(self.layers)}")
            self.update_canvas()

    def prev_layer(self):
        """Переключает на предыдущий слой"""
        if self.layers:
            self.current_layer_index = (self.current_layer_index - 1) % len(self.layers)
            self.layer_label.config(text=f"Слой: {self.current_layer_index + 1}/{len(self.layers)}")
            self.update_canvas()

    def set_mode(self, mode):
        self.mode = mode

    def choose_color(self):
        color = colorchooser.askcolor(color=self.color)[1]
        if color:
            self.color = color
            self.mode = "brush"

    def update_canvas(self):
        """Обновляет отображение холста, комбинируя все видимые слои"""
        # Создаем белый фон
        combined = Image.new("RGBA", (self.width, self.height), (255, 255, 255, 255))
        
        # Комбинируем все видимые слои
        for layer in self.layers:
            if layer['visible']:
                combined = Image.alpha_composite(combined, layer['image'])
        
        # Обновляем отображение
        self.tk_image = ImageTk.PhotoImage(combined)
        self.canvas.delete("all")
        self.canvas.create_image(0, 0, anchor=tk.NW, image=self.tk_image)

    def save_image(self):
        file = filedialog.asksaveasfilename(defaultextension=".png")
        if file:
            # Создаем объединенное изображение для сохранения
            combined = Image.new("RGBA", (self.width, self.height), (255, 255, 255, 255))
            for layer in self.layers:
                if layer['visible']:
                    combined = Image.alpha_composite(combined, layer['image'])
            
            # Конвертируем в RGB (без альфа-канала) для форматов, которые его не поддерживают
            combined = combined.convert("RGB")
            combined.save(file)

    def clear_canvas(self):
        """Очищает текущий слой"""
        layer = self.get_current_layer()
        if layer:
            layer['image'] = Image.new("RGBA", (self.width, self.height), (0, 0, 0, 0))
            layer['draw'] = ImageDraw.Draw(layer['image'])
            self.update_canvas()

    def increase_size(self):
        self.brush_size = min(100, self.brush_size + 1)
        self.size_label.config(text=f"Размер: {self.brush_size}")

    def decrease_size(self):
        self.brush_size = max(1, self.brush_size - 1)
        self.size_label.config(text=f"Размер: {self.brush_size}")

    def on_mousewheel(self, event):
        """Изменение размера кисти колесиком мыши"""
        if event.delta > 0:
            self.increase_size()
        else:
            self.decrease_size()

    def draw_brush(self, x, y, color):
        """Рисует квадратную кисть в указанной позиции"""
        layer = self.get_current_layer()
        if not layer:
            return

        size = self.brush_size
        layer['draw'].rectangle(
            [x - size/2, y - size/2, x + size/2, y + size/2],
            fill=color,
            outline=color
        )

    def draw_eraser(self, x, y):
        """Стирает квадратной области"""
        layer = self.get_current_layer()
        if not layer:
            return

        size = self.brush_size
        # Создаем маску для стирания
        mask = Image.new("L", (self.width, self.height), 0)
        draw_mask = ImageDraw.Draw(mask)
        draw_mask.rectangle(
            [x - size/2, y - size/2, x + size/2, y + size/2],
            fill=255
        )
        
        # Применяем маску (делаем область прозрачной)
        erased = Image.new("RGBA", (self.width, self.height), (0, 0, 0, 0))
        layer['image'] = Image.composite(erased, layer['image'], mask)
        layer['draw'] = ImageDraw.Draw(layer['image'])

    def on_click(self, event):
        self.last_x, self.last_y = event.x, event.y
        self.start_x, self.start_y = event.x, event.y

        layer = self.get_current_layer()
        if not layer:
            return

        if self.mode == "brush":
            self.draw_brush(event.x, event.y, self.color)
            self.update_canvas()
        elif self.mode == "eraser":
            self.draw_eraser(event.x, event.y)
            self.update_canvas()
        elif self.mode == "fill":
            self.bucket_fill(event.x, event.y)
        elif self.mode == "pipette":
            # Получаем цвет из объединенного изображения
            combined = Image.new("RGBA", (self.width, self.height), (255, 255, 255, 255))
            for l in self.layers:
                if l['visible']:
                    combined = Image.alpha_composite(combined, l['image'])
            
            color = combined.getpixel((event.x, event.y))
            self.color = '#%02x%02x%02x' % color[:3]
            self.mode = "brush"
        elif self.mode == "text":
            text = simpledialog.askstring("Текст", "Введите текст:")
            if text:
                layer['draw'].text((event.x, event.y), text, fill=self.color, font=None)
                self.update_canvas()

    def on_drag(self, event):
        layer = self.get_current_layer()
        if not layer:
            return

        if self.mode == "brush":
            # Рисуем кистью с квадратной формой
            self.draw_brush(event.x, event.y, self.color)
            if self.last_x and self.last_y:
                # Интерполируем между точками для плавных линий
                steps = max(abs(event.x - self.last_x), abs(event.y - self.last_y))
                for i in range(1, steps):
                    x = self.last_x + (event.x - self.last_x) * i / steps
                    y = self.last_y + (event.y - self.last_y) * i / steps
                    self.draw_brush(x, y, self.color)
            
            self.last_x, self.last_y = event.x, event.y
            self.update_canvas()

        elif self.mode == "eraser":
            # Стираем квадратной областью
            self.draw_eraser(event.x, event.y)
            if self.last_x and self.last_y:
                # Интерполируем между точками для плавного стирания
                steps = max(abs(event.x - self.last_x), abs(event.y - self.last_y))
                for i in range(1, steps):
                    x = self.last_x + (event.x - self.last_x) * i / steps
                    y = self.last_y + (event.y - self.last_y) * i / steps
                    self.draw_eraser(x, y)
            
            self.last_x, self.last_y = event.x, event.y
            self.update_canvas()

        elif self.mode in ("line", "rect", "oval", "triangle", "star", "polygon"):
            if self.temp_shape:
                self.canvas.delete(self.temp_shape)
            
            if self.mode == "line":
                self.temp_shape = self.canvas.create_line(
                    self.start_x, self.start_y, event.x, event.y, 
                    fill=self.color, width=self.brush_size)
            elif self.mode == "rect":
                self.temp_shape = self.canvas.create_rectangle(
                    self.start_x, self.start_y, event.x, event.y, 
                    outline=self.color, width=self.brush_size)
            elif self.mode == "oval":
                self.temp_shape = self.canvas.create_oval(
                    self.start_x, self.start_y, event.x, event.y, 
                    outline=self.color, width=self.brush_size)
            elif self.mode == "triangle":
                points = self.calculate_triangle(self.start_x, self.start_y, event.x, event.y)
                self.temp_shape = self.canvas.create_polygon(
                    points, outline=self.color, width=self.brush_size, fill="")
            elif self.mode == "star":
                points = self.calculate_star(self.start_x, self.start_y, event.x, event.y)
                self.temp_shape = self.canvas.create_polygon(
                    points, outline=self.color, width=self.brush_size, fill="")
            elif self.mode == "polygon":
                points = self.calculate_polygon(self.start_x, self.start_y, event.x, event.y, self.sides)
                self.temp_shape = self.canvas.create_polygon(
                    points, outline=self.color, width=self.brush_size, fill="")

    def on_release(self, event):
        layer = self.get_current_layer()
        if not layer:
            return

        if self.mode in ("line", "rect", "oval", "triangle", "star", "polygon"):
            if self.temp_shape:
                self.canvas.delete(self.temp_shape)
                self.temp_shape = None
            
            if self.mode == "line":
                layer['draw'].line(
                    [self.start_x, self.start_y, event.x, event.y], 
                    fill=self.color, width=self.brush_size)
            elif self.mode == "rect":
                layer['draw'].rectangle(
                    [self.start_x, self.start_y, event.x, event.y], 
                    outline=self.color, width=self.brush_size)
            elif self.mode == "oval":
                layer['draw'].ellipse(
                    [self.start_x, self.start_y, event.x, event.y], 
                    outline=self.color, width=self.brush_size)
            elif self.mode == "triangle":
                points = self.calculate_triangle(self.start_x, self.start_y, event.x, event.y)
                layer['draw'].polygon(points, outline=self.color, width=self.brush_size)
            elif self.mode == "star":
                points = self.calculate_star(self.start_x, self.start_y, event.x, event.y)
                layer['draw'].polygon(points, outline=self.color, width=self.brush_size)
            elif self.mode == "polygon":
                points = self.calculate_polygon(self.start_x, self.start_y, event.x, event.y, self.sides)
                layer['draw'].polygon(points, outline=self.color, width=self.brush_size)
            
            self.update_canvas()

    def calculate_triangle(self, x1, y1, x2, y2):
        """Вычисляет координаты треугольника"""
        return [x1, y2, x2, y2, (x1 + x2) / 2, y1]

    def calculate_star(self, x1, y1, x2, y2, points=5):
        """Вычисляет координаты звезды"""
        center_x = (x1 + x2) / 2
        center_y = (y1 + y2) / 2
        outer_radius = max(abs(x2 - x1), abs(y2 - y1)) / 2
        inner_radius = outer_radius * 0.4
        
        coords = []
        for i in range(points * 2):
            angle = math.pi / points * i
            radius = inner_radius if i % 2 else outer_radius
            x = center_x + math.cos(angle) * radius
            y = center_y + math.sin(angle) * radius
            coords.extend([x, y])
        
        return coords

    def calculate_polygon(self, x1, y1, x2, y2, sides):
        """Вычисляет координаты многоугольника"""
        center_x = (x1 + x2) / 2
        center_y = (y1 + y2) / 2
        radius = max(abs(x2 - x1), abs(y2 - y1)) / 2
        
        coords = []
        for i in range(sides):
            angle = 2 * math.pi / sides * i
            x = center_x + math.cos(angle) * radius
            y = center_y + math.sin(angle) * radius
            coords.extend([x, y])
        
        return coords

    def bucket_fill(self, x, y):
        """Заливка области с учетом прозрачности"""
        layer = self.get_current_layer()
        if not layer:
            return

        # Получаем текущий цвет пикселя
        target_color = layer['image'].getpixel((x, y))
        
        # Если цвет уже совпадает с целевым, ничего не делаем
        fill_color = self.hex_to_rgba(self.color)
        if target_color == fill_color:
            return
        
        # Создаем маску для заливки
        mask = Image.new("L", (self.width, self.height), 0)
        ImageDraw.floodfill(mask, (x, y), 255, thresh=40)
        
        # Применяем заливку только к выбранной области
        fill = Image.new("RGBA", (self.width, self.height), fill_color)
        layer['image'] = Image.composite(fill, layer['image'], mask)
        layer['draw'] = ImageDraw.Draw(layer['image'])
        
        self.update_canvas()

    def hex_to_rgba(self, hex_color, alpha=255):
        """Конвертирует hex-цвет в RGBA"""
        hex_color = hex_color.lstrip('#')
        r = int(hex_color[0:2], 16)
        g = int(hex_color[2:4], 16)
        b = int(hex_color[4:6], 16)
        return (r, g, b, alpha)

root = tk.Tk()
PaintApp(root)
root.mainloop()